import yfinance as yt
import datetime as datetime
import requests
import openpyxl
import os

def main(tick):
    hoje = datetime.datetime.now()

    while hoje.strftime(format="%w") == "0" or hoje.strftime(format="%w") == "6":
        hoje -= datetime.timedelta(days=1)

    ms = yt.Ticker(tick)

    l = (ms.history())

    if hoje.strftime(format="%w") == "1":
        return float(l.loc[hoje.strftime(format="%Y-%m-%d"), "Open"])
    else:
        return float(l.loc[hoje.strftime(format="%Y-%m-%d"), "Close"])


def get_rate(symbol):
    payload = {"base": "USD", "symbols": symbol}

    response = requests.get("https://api.exchangeratesapi.io/latest", params=payload)

    data = response.json()

    return float(data['rates']["BRL"])


def profit(tick, quantity, price):
    actual = main(tick)
    today = actual * quantity
    past = quantity * price
    if tick.endswith("USD"):
        rate = get_rate("BRL")
        return [(today - past) * rate, actual]
    return [today - past, actual]


def create_ws(lista):
    wb = openpyxl.Workbook()
    ws = wb.active

    ws.cell(row=1, column=1).value = "Ticker"
    ws.cell(row=1, column=2).value = "Date"
    ws.cell(row=1, column=3).value = "Quantity"
    ws.cell(row=1, column=4).value = "Price - Buy"
    ws.cell(row=1, column=5).value = "Total"
    ws.cell(row=1, column=6).value = "Current Price"
    ws.cell(row=1, column=7).value = "Current Total"
    ws.cell(row=1, column=8).value = "Gross Profit"
    ws.cell(row=1, column=9).value = "Profit (%)"

    r = 2
    for k, c, d, n, n1, n2, n3 in lista:
        if not k.endswith("USD"):
            ws.cell(row=r, column=1).value = str(k)
            ws.cell(row=r, column=2).value = d
            ws.cell(row=r, column=3).value = float(n)
            ws.cell(row=r, column=4).value = n1
            ws.cell(row=r, column=5).value = n2
            ws.cell(row=r, column=6).value = n3
            ws.cell(row=r, column=7).value = n * n3
            ws.cell(row=r, column=8).value = float(c)
            ws.cell(row=r, column=9).value = float(c) / n2
            ws.cell(row=r, column=9).number_format = "00.00%"
        else:
            usd = get_rate("BRL")
            ws.cell(row=r, column=1).value = str(k)
            ws.cell(row=r, column=2).value = d
            ws.cell(row=r, column=3).value = float(n)
            ws.cell(row=r, column=4).value = n1 * usd
            ws.cell(row=r, column=5).value = n2 * usd
            ws.cell(row=r, column=6).value = n3 * usd
            ws.cell(row=r, column=7).value = n * n3 * usd
            ws.cell(row=r, column=8).value = float(c)

            ws.cell(row=r, column=9).value = float(c) / (n2 * usd)
            ws.cell(row=r, column=9).number_format = "00.00%"

        r += 1
    wb.save("mystocks.xlsx")
    print(f".xlxs file created at {os.getcwd()}{os.sep}mystocks.xlsx")


lista = []
with open("stocks.txt", "r") as stoc:
    for line in stoc.readlines():
        dados = line.split(",")

        lista.append([dados[0], dados[1], float(dados[2]), float(dados[3].rstrip("\n"))])


profits = []
for operacao in lista:
    prof = profit(operacao[0], operacao[2], operacao[3])
    profits.append([operacao[0], prof[0], operacao[1], operacao[2], operacao[3], operacao[2] * operacao[3], prof[1]])

total = 0
for pr in sorted(profits, key=lambda x: x[1], reverse=True):

    total += pr[1]


create_ws(sorted(profits, key=lambda x: x[1], reverse=True))
